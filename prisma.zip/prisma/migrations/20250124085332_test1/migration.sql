/*
  Warnings:

  - You are about to drop the column `userId` on the `newsletter_archives` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `newsletters` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE `newsletter_archives` DROP FOREIGN KEY `newsletter_archives_userId_fkey`;

-- DropForeignKey
ALTER TABLE `newsletters` DROP FOREIGN KEY `newsletters_userId_fkey`;

-- DropIndex
DROP INDEX `newsletter_archives_userId_fkey` ON `newsletter_archives`;

-- DropIndex
DROP INDEX `newsletters_userId_fkey` ON `newsletters`;

-- AlterTable
ALTER TABLE `newsletter_archives` DROP COLUMN `userId`;

-- AlterTable
ALTER TABLE `newsletters` DROP COLUMN `userId`;
