/*
  Warnings:

  - You are about to drop the `newsletter_archives` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE `newsletter_archives` DROP FOREIGN KEY `newsletter_archives_newsletterId_fkey`;

-- AlterTable
ALTER TABLE `newsletters` ADD COLUMN `contentAsHTML` TEXT NULL;

-- DropTable
DROP TABLE `newsletter_archives`;

-- CreateTable
CREATE TABLE `email_archives` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `newsletterId` INTEGER NOT NULL,
    `sentAt` DATETIME(3) NOT NULL,
    `email` VARCHAR(191) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `email_archives` ADD CONSTRAINT `email_archives_newsletterId_fkey` FOREIGN KEY (`newsletterId`) REFERENCES `newsletters`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
