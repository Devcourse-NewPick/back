-- AlterTable
ALTER TABLE `feedbacks` MODIFY `newsletterId` INTEGER NULL,
    MODIFY `rating` INTEGER NULL;
