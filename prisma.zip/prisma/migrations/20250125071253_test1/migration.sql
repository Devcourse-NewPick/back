-- AlterTable
ALTER TABLE `subscribers` ADD COLUMN `status` VARCHAR(191) NOT NULL DEFAULT 'active';
