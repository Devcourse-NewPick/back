import {
  Controller,
  Get,
  Patch,
  Req,
  Body,
  UnauthorizedException,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { MyPageService } from './mypage.service';

@Controller('mypage')
@UseGuards(AuthGuard('jwt')) // JWT 인증 적용
export class MyPageController {
  constructor(private readonly myPageService: MyPageService) {}

  /**
   * 사용자 프로필 조회
   */
  @Get('profile')
  async getProfile(@Req() req) {
    console.log('Decoded user:', req.user); // 디코딩된 사용자 정보 확인
    const userId = this.validateAndParseUserId(req.user?.userId);
    return this.myPageService.getProfile(userId);
  }

  /**
   * 북마크(좋아요) 조회
   */
  @Get('bookmarks')
  async getBookmarks(@Req() req) {
    const userId = this.validateAndParseUserId(req.user?.userId);
    return this.myPageService.getBookmarks(userId);
  }

  /**
   * 현재 구독 상태 확인
   */
  @Get('subscriptions/status')
  async getSubscriptionStatus(@Req() req) {
    const userId = this.validateAndParseUserId(req.user?.userId);
    return this.myPageService.getSubscriptionStatus(userId);
  }

  /**
   * 전체 구독 기록 조회
   */
  @Get('subscriptions/history')
  async getSubscriptionHistory(@Req() req) {
    const userId = this.validateAndParseUserId(req.user?.userId);
    return this.myPageService.getSubscriptionHistory(userId);
  }

  /**
   * 관심사 조회
   */
  @Get('interests')
  async getInterests(@Req() req) {
    const userId = this.validateAndParseUserId(req.user?.userId);
    return this.myPageService.getInterests(userId);
  }

  /**
   * 관심사 수정
   */
  @Patch('interests')
  async updateInterests(@Req() req, @Body('interests') interests: string[]) {
    const userId = this.validateAndParseUserId(req.user?.userId);
    const validInterests = ['정치', '사회', 'IT'];

    // 유효성 검사
    if (!interests || interests.some((interest) => !validInterests.includes(interest))) {
      throw new UnauthorizedException('Invalid interests provided');
    }

    return this.myPageService.updateInterests(userId, interests);
  }

  /**
   * userId를 검증하고 Int로 변환
   */
  private validateAndParseUserId(userId: string | number | undefined): number {
    console.log('Raw userId:', userId); // 원본 userId 값 출력
    if (!userId) {
      throw new UnauthorizedException('User not authenticated');
    }

    const parsedId = typeof userId === 'string' ? parseInt(userId, 10) : userId;

    console.log('Parsed userId:', parsedId); // 변환된 userId 확인

    if (isNaN(parsedId) || parsedId < -2147483648 || parsedId > 2147483647) {
      throw new UnauthorizedException('Invalid or out-of-range user ID');
    }

    return parsedId;
  }
}
